export const API_PREFIX_V1 = "api/v1";

export const API_ACCESS_ROLES = ["admin", "manager"];
